package Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.User;
import com.example.demo.Services.UserService;

@RestController
public class UserController {
	@Autowired
	UserService userv;
	
	@GetMapping("/getUser")
	public User getUser(@RequestParam int uid) {
		return userv.getOne(uid);
	}
	
	@GetMapping("/getAllUser")
	public List<User> getAll(){
		return userv.getAll();
	}
	
	@PostMapping("/saveUser")
	public User saveUser(@RequestBody User u){
		return userv.saveUser(u);
	}
	
	@DeleteMapping("/deleteUser")
	public void deleteUser(int uid){
		userv.deleteUser(uid);
	}
}
