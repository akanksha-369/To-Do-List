package com.example.demo.Entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "date")
public class Date {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int day;
	int month;
	int year;
	@OneToMany(mappedBy = "Date", cascade=CascadeType.ALL)
	List<Date> uList= new ArrayList<>();
	
}
