package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.Status;

public interface StatusRepo extends JpaRepository<Status, Integer>{

}
