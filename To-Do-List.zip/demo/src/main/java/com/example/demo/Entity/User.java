package com.example.demo.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "user")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int uid;
	@ManyToOne
	@JoinColumn(name = "sid", nullable = false)
	Status status;
	@ManyToOne
	@JoinColumn(name = "pid", nullable = false)
	Priority priority;
	@ManyToOne
	@JoinColumn(name = "day", nullable = false)
	Date date;
	
	public User() {
	}
	
	public User(int uid, Status status, Priority priority, Date date) {
		super();
		this.uid = uid;
		this.status = status;
		this.priority = priority;
		this.date = date;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}
}
