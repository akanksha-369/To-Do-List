package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.Priority;

public interface PriorityRepo extends JpaRepository<Priority, Integer> {

}
