package com.example.demo.Entity;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.Entity.User;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "status")
public class Status {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int sid;
	String sname;
	@OneToMany(mappedBy = "status", cascade=CascadeType.ALL)
	List<User> uList= new ArrayList<>();
	
	public Status() {
	}
	
	public Status(int sid, String status) {
		super();
		this.sid = sid;
		this.sname = status;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getStatus() {
		return sname;
	}
	public void setStatus(String status) {
		this.sname = status;
	}
	
	
}
