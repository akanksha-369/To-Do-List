package com.example.demo.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.EfarmingRESTServices.entities.Product;
import com.example.demo.Entity.Status;
import com.example.demo.Entity.User;
import com.example.demo.Repository.StatusRepo;
import com.example.demo.Repository.UserRepo;

@Service
public class UserService {
	@Autowired
	UserRepo urepo;
	
	@Autowired
	StatusRepo srepo;
	
	public List<User> getAll() {
		return urepo.findAll();
	}
	
	public User getOne(int uid) {
		User u = null;
		Optional<User> uone = urepo.findById(uid);
		try { 
			u = uone.get();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return u;
	}
	
	public User saveUser(User u) {
		return urepo.save(u);
	}
	
	//Return All users having status
	public List<User> getByStatus(int sid) {
		User u = urepo.findById(sid)
              .orElseThrow(() -> new RuntimeException("User with Status ID " + sid + " is not found."));
		return urepo.findAllById(sid);
	}
	
	//Return all users having same priority
	public List<User> getByPriority(int pid) {
		User u = urepo.findById(pid)
              .orElseThrow(() -> new RuntimeException("User with Priority ID " + pid + " is not found."));
		return urepo.findAllById(pid);
	}
	
	public void deleteUser(int uid) {
		urepo.deleteById(uid);
	}
}
