package com.example.demo.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Status;
import com.example.demo.Entity.User;
import com.example.demo.Repository.StatusRepo;

@Service
public class StatusService {
	@Autowired 
	StatusRepo srepo;
	
	public List<Status> getAll() {
		return srepo.findAll();
	}
	
}
